import Todo from './todo';
import React from 'react';
import TodoListItem from './todo_list_item';
import TodoForm from './todo_form';
import store from '../../store/store';

const TodoList = ({todos, receiveTodo}) => {
  return (
    <section>
      <TodoForm receiveTodo={receiveTodo} />
      <ul>
        {
          todos.map((todo, i) => (
             <TodoListItem todo={todo} key={i} />
          ))
        }
      </ul>
    </section>
  );
};

export default TodoList;

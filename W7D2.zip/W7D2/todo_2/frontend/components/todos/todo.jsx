import React from 'react';

class Todo extends React.Component {
  constructor(){
    super();
  }

  render() {
    return (
      <h1>Todos App</h1>
    );
  }
}

export default Todo;
